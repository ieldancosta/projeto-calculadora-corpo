﻿// Namespaces
using System;
using System.Collections.Generic;
using System.Linq;


// Classe
class Program
{
    static void Main(string[] args)
    {
        // Instâncias
        Pessoa pessoa1 = new Pessoa("Daniel", 20, 70, 176);
        Pessoa pessoa2 = new Pessoa("Matheus", 23, 40, 150);
        Pessoa pessoa3 = new Pessoa("Stanley", 20, 80, 170);

        Calculadora calculadora = new Calculadora();

        
        // Execução
        pessoa1.mostrarDados();
        Console.WriteLine();
        pessoa2.mostrarDados();
        Console.WriteLine();
        
        double resultado = calculadora.calcularIMCTeste(pessoa1);
        string status = calculadora.classificarIMC(resultado);
        Console.WriteLine(status);

        double testando = calculadora.calcularIMC(pessoa1.Peso, pessoa1.Altura);
        Console.WriteLine(status);
    }
}