// Namespaces
using System;


// Classe
class Calculadora
{
    // Métodos

    // Calcular o IMC (Índice de Massa Corporal)
    public double calcularIMC(double peso, double altura)
    {
        double alturaEmMetros = altura / 100;
        double IMC = peso / (alturaEmMetros * alturaEmMetros);
        return IMC;
    }

    public double calcularIMCTeste(Pessoa pessoa)
    {
        if (pessoa.Altura == 0) return 0;

        double IMC = pessoa.Peso / (pessoa.Altura * pessoa.Altura);

        return Math.Round(IMC, 2);
    }

    // Calcular o GER (Gasto Energético em Repouso), também chamado de TMB (Taxa Metabólica Basal)
    public double calcularGER()
    {
        double GER = 0;
        return GER;
    }

    // Calcular o ETA (Efeito Térmico dos Alimentos)
    public double calcularETA()
    {
        double ETA = 0;
        return ETA;
    }

    // Calcular o GAF (Gasto de Atividade Física)
    public double calcularGAF(double fatorAtividade, double GER)
    {
        double GAF = fatorAtividade * GER;
        return GAF;
    }

    // Calcular o NEAT (Termogênese Não Relacionada ao Exercício Físico)
    public double calcularNEAT()
    {
        double NEAT = 0;
        return NEAT;
    }

    // Calcular o GET (Gasto Energético Total)
    public double calcularGET(double GER, double ETA, double GAF, double NEAT)
    {
        double GET = GER + ETA + GAF + NEAT;
        return GET;
    }
    

    // Exibir a Classificação do IMC (Índice de Massa Corporal)
    public string classificarIMC(double IMC)
    {
        if (IMC < 18.5) return "Abaixo do peso";
        if (IMC < 25) return "Peso normal";
        if (IMC < 30) return "Sobrepeso";
        return "Obesidade";
    }
}