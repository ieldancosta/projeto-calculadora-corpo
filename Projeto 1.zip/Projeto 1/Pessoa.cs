// Namespaces
using System;


// Classe
class Pessoa
{
    // Propriedades
    public string Nome { get; set; }
    public int Idade { get; set; }
    public double Peso { get; set; }
    public double Altura { get; set; }


    // Construtor
    public Pessoa(string nome, int idade, double peso, double altura)
    {
        this.Nome = nome;
        this.Idade = idade;
        this.Peso = peso;
        this.Altura = altura;
    }


    // Métodos
    public void mostrarDados()
    {
        Console.WriteLine($"Nome: {Nome}\nIdade: {Idade}\nPeso: {Peso}\nAltura: {Altura}");
    }
}